#include "tvm/runtime/c_runtime_api.h"
#ifdef __cplusplus
extern "C" {
#endif
__attribute__((section(".rodata.tvm"), ))
static struct global_const_workspace {
  float fused_constant_1_let[240] __attribute__((aligned(16))); // 960 bytes, aligned offset: 0
  float fused_constant_let[72] __attribute__((packed, aligned(16))); // 288 bytes, aligned offset: 960
  float fused_nn_contrib_dense_pack_constant_let[10] __attribute__((packed, aligned(16))); // 40 bytes, aligned offset: 1248
  float fused_nn_conv2d_constant_let[6] __attribute__((packed, aligned(16))); // 24 bytes, aligned offset: 1296
} global_const_workspace = {
  .fused_constant_1_let = {
    -0x1.d1503ep-2, 0x1.a20874p-4, -0x1.2e8172p-2, 0x1.d0639cp-5, -0x1.0c524p-3, -0x1.5f3b52p-3, -0x1.783028p-4, 0x1.dabc1p-5, 
    0x1.ca8d58p-5, -0x1.5819c8p-2, -0x1.d02b4ep-3, 0x1.71aad4p-3, -0x1.5a2c42p-3, -0x1.d62978p-3, -0x1.c7fce6p-6, -0x1.b22c38p-5, 
    0x1.1475cap-7, -0x1.06b868p-2, -0x1.58ec5cp-4, 0x1.88c6cap-3, 0x1.534724p-4, 0x1.bdbb9p-2, -0x1.039ap-2, -0x1.bcbb76p-3, 
    -0x1.a4505cp-3, 0x1.2c042ap-4, 0x1.3f001ap-2, -0x1.758ebep-2, -0x1.697c7cp-2, -0x1.bfbf14p-3, 0x1.6e3704p-2, 0x1.60f734p-2, 
    -0x1.2fe8bcp-2, -0x1.769bfep-2, -0x1.2e8deep-2, 0x1.c5a532p-2, 0x1.b97406p-2, -0x1.0dca62p-3, -0x1.8482ccp-2, -0x1.4ef28cp-2, 
    -0x1.512802p-4, -0x1.8fcd28p-4, 0x1.9c57d6p-5, 0x1.23345ep-3, 0x1.22ff3ap-3, -0x1.a6a91ap-3, -0x1.26be34p-3, 0x1.06079ep-3, 
    0x1.1b1f12p-2, 0x1.34bb52p-3, 0x1.cfc54cp-5, 0x1.0e4884p-3, -0x1.c8a0eep-5, -0x1.b9b32ep-4, -0x1.93dc78p-3, -0x1.9cfc14p-4, 
    0x1.1dded2p-3, -0x1.4ad8d6p-4, 0x1.646e72p-4, -0x1.43cb48p-3, 0x1.576af8p-6, 0x1.876c1ap-6, -0x1.7d562p-3, -0x1.f58b06p-3, 
    -0x1.3df7dp-2, 0x1.d94b18p-3, -0x1.5b3c8ep-9, -0x1.876bb6p-4, -0x1.25a09ep-3, -0x1.7683bep-2, 0x1.a8ecb8p-4, 0x1.01a9b6p-6, 
    0x1.826e7p-5, 0x1.c115ap-2, -0x1.c482e6p-4, 0x1.67b9fcp-5, -0x1.a031a6p-4, 0x1.8258bap-5, 0x1.997a7ep-2, -0x1.8b6f82p-3, 
    -0x1.77851p-2, -0x1.e0290ep-3, 0x1.7e1facp-4, 0x1.2ab31cp-3, 0x1.0ca3f8p-4, -0x1.1174acp-2, -0x1.815ap-3, -0x1.a7643p-5, 
    0x1.ab3072p-4, 0x1.955208p-7, -0x1.0cf26ep-3, 0x1.1d7dc2p-8, -0x1.6aa8aep-4, 0x1.517546p-5, 0x1.7e6fb2p-5, -0x1.0f7784p-4, 
    0x1.3a85e4p-10, 0x1.18495cp-3, -0x1.690214p-3, 0x1.18875cp-2, 0x1.88c902p-2, -0x1.7cfb6cp-3, 0x1.5634dep-2, -0x1.11f1a6p-2, 
    0x1.9bfc2cp-2, 0x1.f66636p-3, -0x1.43ee34p-5, 0x1.13dd8p-3, 0x1.01186cp-4, 0x1.89575p-2, 0x1.728876p-4, -0x1.a46f72p-3, 
    0x1.0ddc3ep-3, 0x1.63468cp-4, 0x1.c14c9p-3, 0x1.63e864p-2, -0x1.8cf5ep-4, 0x1.bcacp-2, -0x1.7d11eap-3, 0x1.295d76p-4, 
    0x1.14bf2p-2, 0x1.eece42p-3, 0x1.d1b94cp-4, -0x1.5b9926p-2, -0x1.7593a8p-6, 0x1.6a48ep-5, 0x1.157618p-3, 0x1.0601dcp-2, 
    -0x1.0c9da6p-1, 0x1.7549f8p-7, -0x1.013ddcp-2, 0x1.f48314p-4, 0x1.2feb94p-2, -0x1.c34764p-3, 0x1.e44c6cp-2, -0x1.7ece02p-4, 
    0x1.59dad8p-3, -0x1.53ca0cp-4, -0x1.78c92cp-2, 0x1.2d636ap-3, -0x1.095b42p-2, -0x1.47ed6cp-2, 0x1.078f8cp-2, 0x1.5ea22p-4, 
    0x1.d52d8ap-4, -0x1.0fb088p-2, -0x1.fa82aep-3, 0x1.0d0b32p-2, 0x1.0e0ec4p-3, 0x1.409402p-2, -0x1.0e6b32p-1, -0x1.aebf6ep-5, 
    -0x1.225c24p-2, 0x1.4662fap-4, 0x1.d46246p-2, -0x1.65aa74p-2, -0x1.773078p-4, -0x1.ebf198p-6, 0x1.d947dap-3, 0x1.34d9d6p-2, 
    0x1.57072ap-2, 0x1.359c5p-3, 0x1.94bb32p-3, -0x1.34ebeep-2, -0x1.879e1ep-3, 0x1.c6c1a2p-4, -0x1.53ede2p-6, 0x1.b215c6p-3, 
    -0x1.2b4d34p-2, -0x1.b7e942p-4, -0x1.0ff6dcp-2, -0x1.1181ecp-4, -0x1.8c448p-4, 0x1.35cfbcp-2, 0x1.449e4ep-6, -0x1.8cb3cep-5, 
    -0x1.311656p-5, -0x1.efe9ccp-3, 0x1.ef2c5ap-3, 0x1.c82adep-3, -0x1.43dc92p-4, -0x1.b89c2ep-2, 0x1.11f236p-2, -0x1.7b4d72p-6, 
    0x1.6af39ep-2, 0x1.54c22ap-5, -0x1.12e07cp-1, 0x1.2c5c4cp-2, 0x1.e0c28cp-3, 0x1.ca469p-2, 0x1.ee5c2ep-3, -0x1.963d4p-6, 
    -0x1.5a7de2p-2, 0x1.94407p-4, -0x1.3a13aap-2, 0x1.4b22aap-2, -0x1.5a9cf6p-4, -0x1.be109ap-2, 0x1.dbc92ep-5, -0x1.6c9028p-2, 
    0x1.d79eacp-3, 0x1.1fd2ecp-4, -0x1.5ebb28p-6, -0x1.cb9338p-2, -0x1.b35106p-3, 0x1.33c86cp-2, 0x1.f54d1ap-5, 0x1.9ad40ep-5, 
    -0x1.c7af5p-2, -0x1.af1baep-2, -0x1.4ee5e8p-4, 0x1.1e810ep-2, -0x1.58f4a2p-3, 0x1.31df5ap-7, -0x1.9c2bc4p-4, -0x1.2a765p-6, 
    0x1.3959b8p-3, 0x1.4c6f8ap-6, 0x1.5f681ep-5, 0x1.57141p-3, -0x1.8aeb3ep-5, -0x1.c46b08p-3, -0x1.597c7ap-3, 0x1.736b52p-2, 
    0x1.5fdcecp-8, -0x1.bc3804p-4, 0x1.4543dcp-4, 0x1.b524a6p-4, 0x1.67a7fap-6, -0x1.f1804ep-3, -0x1.11f8f4p-4, -0x1.14158p-6, 
    -0x1.9c2da8p-3, 0x1.5e7fc2p-4, -0x1.276d12p-2, -0x1.b6235ap-3, -0x1.20f93ap-5, -0x1.ca4bd2p-3, 0x1.e6f59cp-3, -0x1.63258ap-4
  },
  .fused_constant_let = {
    0x1.0745b4p-2, -0x1.ca2bfep-1, -0x1.8afe2ap-2, -0x1.c65078p-2, -0x1.fb0d24p-3, -0x1.5c61b6p-3, 0x1.029602p-2, -0x1.9fa13ap-1, 
    -0x1.c0cb42p-6, -0x1.617ef2p-4, -0x1.1a173ep-4, -0x1.2273e4p-5, -0x1.9bac22p-6, -0x1.29fe18p-5, -0x1.b99b12p-4, -0x1.41236p-5, 
    0x1.2b760ap-3, -0x1.331c54p-2, 0x1.831aacp-2, -0x1.1340f8p-4, -0x1.acaaaep-3, -0x1.ec607cp-2, 0x1.468342p-5, -0x1.d95a98p-3, 
    -0x1.a65d1ap-3, -0x1.238408p-1, -0x1.af92d6p-3, -0x1.0292d8p-4, -0x1.014bfp-2, 0x1.6472cp-9, -0x1.d8955cp-3, -0x1.05fd2ap-1, 
    -0x1.f68fbp-2, -0x1.e3a188p-4, -0x1.495d2ap-3, 0x1.091316p-5, -0x1.10421p-1, 0x1.258b7ep-3, -0x1.7e06aap-2, 0x1.7e2d9p-4, 
    -0x1.f8dbdep-6, 0x1.add792p-3, 0x1.30fc18p-1, 0x1.17161cp-2, -0x1.a0daccp-2, 0x1.92bbe4p-3, 0x1.33a3p-3, -0x1.9977ap-3, 
    -0x1.28c32p-2, 0x1.4ae3d8p-4, -0x1.447f4cp-1, 0x1.9a783ep-1, -0x1.056148p-1, -0x1.6a90cap-5, -0x1.2f32d8p-2, -0x1.8af9e8p-3, 
    -0x1.01c108p-1, 0x1.8a855ap-1, -0x1.580c58p-1, 0x1.8acf6ep-4, -0x1.147846p-1, 0x1.86ed18p-1, -0x1.a54704p-2, 0x1.4ab206p-1, 
    -0x1.f910fep-2, 0x1.21fbb2p-2, 0x1.49fbd2p-3, 0x1.5b8abap-1, -0x1.eb0c3cp-2, 0x1.9750b8p-1, -0x1.1c1274p-1, 0x1.6bec64p-2
  },
  .fused_nn_contrib_dense_pack_constant_let = {
    0x1.39c9fep-2, -0x1.1395ecp-1, 0x1.d3764cp-2, -0x1.6612c4p-4, 0x1.b5dc22p-2, 0x1.22419ap-7, -0x1.045626p-8, -0x1.66c406p-5, 
    0x1.3dbc94p-2, -0x1.bb80a8p-2
  },
  .fused_nn_conv2d_constant_let = {
    -0x1.ad8ddp-3, -0x1.c83408p-2, 0x1.b78f38p-4, -0x1.50317ap-5, 0x1.0d8f78p-2, 0x1.ac30dp-1
  },
};// of total size 1320 bytes
__attribute__((section(".bss.noinit.tvm"), aligned(8)))
static uint8_t global_workspace[61100];
#include <tvmgen_default.h>
TVM_DLL int32_t tvmgen_default___tvm_main__(void* input,void* output0,uint8_t* global_const_workspace_0_var,uint8_t* global_workspace_1_var);
int32_t tvmgen_default_run(struct tvmgen_default_inputs* inputs,struct tvmgen_default_outputs* outputs) {return tvmgen_default___tvm_main__(inputs->input,outputs->output,((uint8_t*)&global_const_workspace),((uint8_t*)&global_workspace));
}
#ifdef __cplusplus
}
#endif
;