// tvm target: c -keys=arm_cpu,cpu -mcpu=cortex-m4
#define TVM_EXPORTS
#include "tvm/runtime/c_runtime_api.h"
#include "tvm/runtime/c_backend_api.h"
#include <math.h>
#include <stdbool.h>
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_contrib_dense_pack_add(float* p0, float* T_add, uint8_t* global_const_workspace_6_var, uint8_t* global_workspace_7_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_nn_relu(float* p0, float* T_relu, uint8_t* global_const_workspace_2_var, uint8_t* global_workspace_3_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_max_pool2d(float* p0, float* pool_max, uint8_t* global_const_workspace_4_var, uint8_t* global_workspace_5_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default___tvm_main__(float* input_buffer_var, float* output_buffer_var, uint8_t* global_const_workspace_0_var, uint8_t* global_workspace_1_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_contrib_dense_pack_add(float* p0, float* T_add, uint8_t* global_const_workspace_6_var, uint8_t* global_workspace_7_var) {
  void* fused_nn_contrib_dense_pack_constant_let = (&(global_const_workspace_6_var[1248]));
  void* fused_constant_1_let = (&(global_const_workspace_6_var[0]));
  for (int32_t ax1_outer_ax0_outer_fused = 0; ax1_outer_ax0_outer_fused < 2; ++ax1_outer_ax0_outer_fused) {
    void* compute_global_let = (&(global_workspace_7_var[61080]));
    for (int32_t x_c_init = 0; x_c_init < 5; ++x_c_init) {
      ((float*)compute_global_let)[x_c_init] = 0.000000e+00f;
    }
    for (int32_t k_outer = 0; k_outer < 24; ++k_outer) {
      for (int32_t x_c = 0; x_c < 5; ++x_c) {
        ((float*)compute_global_let)[x_c] = (((float*)compute_global_let)[x_c] + (p0[k_outer] * ((float*)fused_constant_1_let)[(((ax1_outer_ax0_outer_fused * 120) + (k_outer * 5)) + x_c)]));
      }
    }
    for (int32_t ax1_inner_inner = 0; ax1_inner_inner < 5; ++ax1_inner_inner) {
      int32_t cse_var_1 = ((ax1_outer_ax0_outer_fused * 5) + ax1_inner_inner);
      T_add[cse_var_1] = (((float*)compute_global_let)[ax1_inner_inner] + ((float*)fused_nn_contrib_dense_pack_constant_let)[cse_var_1]);
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_nn_relu(float* p0, float* T_relu, uint8_t* global_const_workspace_2_var, uint8_t* global_workspace_3_var) {
  void* fused_nn_conv2d_constant_let = (&(global_const_workspace_2_var[1296]));
  void* fused_constant_let = (&(global_const_workspace_2_var[960]));
  void* data_vec_let = (&(global_workspace_3_var[0]));
  void* conv_let = (&(global_workspace_3_var[60984]));
  for (int32_t h = 0; h < 33; ++h) {
    for (int32_t w = 0; w < 11; ++w) {
      for (int32_t ci = 0; ci < 3; ++ci) {
        for (int32_t vh = 0; vh < 2; ++vh) {
          for (int32_t vw = 0; vw < 4; ++vw) {
            int32_t cse_var_2 = (h + vh);
            int32_t cse_var_1 = (w * 3);
            ((float*)data_vec_let)[(((((h * 264) + (w * 24)) + (ci * 8)) + (vh * 4)) + vw)] = (((((1 <= cse_var_2) && (cse_var_2 < 33)) && (1 <= (cse_var_1 + vw))) && (((vw / 3) + w) < 11)) ? p0[((((((ci * 1024) + (h * 32)) + (vh * 32)) + cse_var_1) + vw) - 33)] : 0.000000e+00f);
          }
        }
      }
    }
  }
  for (int32_t ax2_outer = 0; ax2_outer < 33; ++ax2_outer) {
    for (int32_t ax3_outer = 0; ax3_outer < 11; ++ax3_outer) {
      for (int32_t vw_init = 0; vw_init < 3; ++vw_init) {
        for (int32_t vc_init = 0; vc_init < 6; ++vc_init) {
          ((float*)conv_let)[((vw_init * 6) + vc_init)] = 0.000000e+00f;
        }
      }
      for (int32_t ci_1 = 0; ci_1 < 3; ++ci_1) {
        for (int32_t kh = 0; kh < 2; ++kh) {
          for (int32_t kw = 0; kw < 2; ++kw) {
            for (int32_t vw_1 = 0; vw_1 < 3; ++vw_1) {
              for (int32_t vc = 0; vc < 6; ++vc) {
                int32_t cse_var_3 = ((vw_1 * 6) + vc);
                ((float*)conv_let)[cse_var_3] = (((float*)conv_let)[cse_var_3] + (((float*)data_vec_let)[((((((ax2_outer * 264) + (ax3_outer * 24)) + (ci_1 * 8)) + (kh * 4)) + vw_1) + kw)] * ((float*)fused_constant_let)[((((ci_1 * 24) + (kh * 12)) + (kw * 6)) + vc)]));
              }
            }
          }
        }
      }
      for (int32_t ax3_inner = 0; ax3_inner < 3; ++ax3_inner) {
        for (int32_t ax1_inner = 0; ax1_inner < 6; ++ax1_inner) {
          float v_ = ((float*)conv_let)[((ax3_inner * 6) + ax1_inner)] + ((float*)fused_nn_conv2d_constant_let)[ax1_inner];
          T_relu[((((ax1_inner * 1089) + (ax2_outer * 33)) + (ax3_outer * 3)) + ax3_inner)] = ((v_) > (0.000000e+00f) ? (v_) : (0.000000e+00f));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_max_pool2d(float* p0, float* pool_max, uint8_t* global_const_workspace_4_var, uint8_t* global_workspace_5_var) {
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 6; ++ax0_ax1_fused) {
    for (int32_t ax2 = 0; ax2 < 2; ++ax2) {
      for (int32_t ax3 = 0; ax3 < 2; ++ax3) {
        pool_max[(((ax0_ax1_fused * 4) + (ax2 * 2)) + ax3)] = -3.402823e+38f;
        for (int32_t rv0 = 0; rv0 < 16; ++rv0) {
          for (int32_t rv1 = 0; rv1 < 16; ++rv1) {
            int32_t cse_var_1 = (((ax0_ax1_fused * 4) + (ax2 * 2)) + ax3);
            float v_ = pool_max[cse_var_1];
            float v__1 = p0[(((((ax0_ax1_fused * 1089) + (ax2 * 528)) + (rv0 * 33)) + (ax3 * 16)) + rv1)];
            pool_max[cse_var_1] = ((v_) > (v__1) ? (v_) : (v__1));
          }
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default___tvm_main__(float* input_buffer_var, float* output_buffer_var, uint8_t* global_const_workspace_0_var, uint8_t* global_workspace_1_var) {
  void* sid_1_let = (&(global_workspace_1_var[34848]));
  void* sid_2_let = (&(global_workspace_1_var[60984]));
  if (tvmgen_default_fused_nn_conv2d_add_nn_relu(input_buffer_var, sid_1_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_max_pool2d(sid_1_let, sid_2_let, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  if (tvmgen_default_fused_nn_contrib_dense_pack_add(sid_2_let, output_buffer_var, global_const_workspace_0_var, global_workspace_1_var) != 0 ) return -1;
  return 0;
}

