Current Mbed version is 6.17.0:

https://github.com/ARMmbed/mbed-os/releases/tag/mbed-os-6.17.0

This is corresponding commit url:

https://github.com/ARMmbed/mbed-os/commit/17dc3dc2e6e2817a8bd3df62f38583319f0e4fed

To change Mbed version change the commit url in mbed-os.lib.
