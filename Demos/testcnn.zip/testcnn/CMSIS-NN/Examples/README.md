# CMSIS-NN examples

All CMSIS-NN examples are external, please follow the links to the respective repositories to find how they were implemented.

## Image recognition on STMicroelectonics(R) STM32F4 using Arm(R) Mbed(TM) CLI 2

Image recognition on the STM32F4 board utilizing CMSIS-NN and Mbed CLI 2.

Visit [here](https://github.com/ARM-software/ML-examples/tree/master/tflm-cmsisnn-mbed-image-recognition) for more information and the source code. There is also a [blog post](https://community.arm.com/arm-community-blogs/b/ai-and-ml-blog/posts/image-recognition-on-arm-powered-microcontrollers) for this demo.
