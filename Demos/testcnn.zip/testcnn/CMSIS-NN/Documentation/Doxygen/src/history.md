# Revision History {#rev_hist}

The table below provides information about the changes delivered with specific versions of CMSIS-NN.
